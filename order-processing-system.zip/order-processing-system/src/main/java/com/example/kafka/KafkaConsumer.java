// File: com.example.kafka.KafkaConsumer.java
package com.example.kafka;

@FunctionalInterface
public interface KafkaConsumer {
    void consume(KafkaMessage message);
}
