package com.example.kafka;

public enum KafkaTopic {
    ORDER_PLACED,
    ORDER_PROCESSING,
    ORDER_SHIPPED,
    ORDER_DELIVERED
}
