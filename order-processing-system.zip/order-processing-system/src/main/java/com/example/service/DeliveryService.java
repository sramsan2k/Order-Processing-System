package com.example.service;

public interface DeliveryService {
    void deliverOrder(String orderId); // Optional manual trigger if needed
}
