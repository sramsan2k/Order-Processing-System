package com.example.service;

public interface ShippingService {
    void shipOrder(String orderId);

}
